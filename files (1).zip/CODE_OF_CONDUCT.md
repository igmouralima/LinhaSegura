# Código de Conduta

## Nosso Compromisso
Como participantes deste projeto, nós nos comprometemos a manter um ambiente acolhedor, respeitoso e inclusivo para todos.

## Comportamentos Esperados
- Demonstrar empatia e respeito por todos.
- Aceitar críticas construtivas de forma respeitosa.
- Focar no que é melhor para a comunidade.

## Comportamentos Inaceitáveis
- Uso de linguagem ou imagens inadequadas.
- Assédio ou discriminação de qualquer tipo.

## Aplicação
O comportamento inaceitável pode ser relatado diretamente para a equipe em **[email de contato]**.